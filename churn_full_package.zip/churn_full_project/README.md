# Customer Churn Prediction Project

This project includes:
- Refactored ML pipeline
- Streamlit App
- SHAP Explainability Notebook
- Deployment-ready folder structure
